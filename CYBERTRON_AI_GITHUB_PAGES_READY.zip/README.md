# CYBERTRON AI — GitHub Pages package

**AI THAT PROTECTS — Be Aware. Be Cyber Alert. Be a Cybertronian.**

## Files

- `index.html` — complete browser-based CYBERTRON AI prototype. The original CYBERTRON logo and Sandra artwork are embedded in the HTML, so no separate image files are required.

## Run locally

1. Extract this ZIP.
2. Open `index.html` in Chrome or Edge.

## Publish as a website with GitHub Pages

1. Extract this ZIP on your computer.
2. In your GitHub repository, upload the **contents** of the extracted folder to the repository root. Do not upload only the ZIP if you want Pages to publish the website.
3. Ensure the homepage is named exactly `index.html` (lowercase) and is in the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select branch `main` and folder `/(root)`, then save.
6. Open the GitHub Pages URL shown in Settings → Pages after deployment completes.

## Important

GitHub's `raw.githubusercontent.com` address displays source code as text; it is not the rendered website. Use the GitHub Pages URL to view the website.

## Prototype limitations

This is a local educational prototype. Sandra uses a programmed knowledge base; it is not a live generative-AI service. Message and URL checks use browser-side heuristics, not live threat-intelligence verification. Some optional browser capabilities may vary by browser and internet connection.
